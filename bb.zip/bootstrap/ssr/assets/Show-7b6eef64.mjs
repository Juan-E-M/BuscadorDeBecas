import { j as jsxs, a as jsx } from "../ssr.mjs";
import { A as Authenticated } from "./AuthenticatedLayout-f12fe069.mjs";
import { usePage, Head } from "@inertiajs/react";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "react";
import "./ApplicationLogo-f5319d5c.mjs";
import "@headlessui/react";
function Show(props) {
  const user = usePage().props.user;
  const userFields = [
    { label: "Nombre", value: user.name },
    { label: "Apellido", value: user.lastname },
    { label: "Email", value: user.email },
    { label: "Número de Teléfono", value: user.phone_number },
    { label: "Institución de Trabajo", value: user.work_institution },
    { label: "Institución Educativa", value: user.college_institution },
    { label: "Grado Académico", value: user.academic_degree },
    { label: "Fecha de Nacimiento", value: user.birth_date }
  ];
  const formatDate = (date) => {
    const parsedDate = new Date(date);
    const day = parsedDate.getDate();
    const month = parsedDate.getMonth() + 1;
    const year = parsedDate.getFullYear();
    return `${day}/${month}/${year}`;
  };
  const formatField = (field) => {
    if (field.label === "Fecha de Nacimiento") {
      return formatDate(field.value);
    } else {
      return field.value;
    }
  };
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Información Usuario" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Info Usuario" }),
        /* @__PURE__ */ jsx("section", { className: "p-6 mt-2 max-w-7xl mx-auto sm:px-6 lg:px-8 rounded-lg shadow-md", children: /* @__PURE__ */ jsx("div", { className: "mx-auto grid grid-cols-2 md:grid-cols-2 gap-4 mt-6 justify-center text-center", children: userFields.map((field, key) => /* @__PURE__ */ jsxs("div", { children: [
          /* @__PURE__ */ jsx("h2", { className: "text-lg font-medium text-gray-900", children: field.label }),
          /* @__PURE__ */ jsx("p", { className: "mt-1 text-sm text-gray-600", children: formatField(field) })
        ] }, key)) }) })
      ]
    }
  );
}
export {
  Show as default
};
