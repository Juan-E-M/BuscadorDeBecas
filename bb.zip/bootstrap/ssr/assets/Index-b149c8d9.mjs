import { j as jsxs, a as jsx } from "../ssr.mjs";
import { Head, Link } from "@inertiajs/react";
import { useState, useRef, useEffect } from "react";
import { A as Authenticated } from "./AuthenticatedLayout-f12fe069.mjs";
import ExcelReportButton from "./ExcelReportButton-90d9e0bc.mjs";
import "react/jsx-runtime";
import "react-dom/server";
import "@inertiajs/react/server";
import "./ApplicationLogo-f5319d5c.mjs";
import "@headlessui/react";
import "exceljs";
const defaultValues = {
  ocde: "",
  ods: "",
  country: "",
  type: "",
  startDate: "",
  endDate: "",
  status: ""
};
function Index(props) {
  const { becas, ocdes, odss, countries } = props;
  const [odsOptions, setOdsOptions] = useState(odss);
  const [ocdeOptions, setOcdeOptions] = useState(ocdes);
  const [searchFilters, setSearchFilters] = useState({ ...defaultValues });
  const odsSelect = useRef();
  const ocdeSelect = useRef();
  const handleClean = () => {
    setSearchFilters({ ...defaultValues });
  };
  const handleSearch = (e) => {
    setSearchFilters({ ...searchFilters, [e.target.name]: e.target.value });
  };
  let data = becas.filter((beca) => {
    const ocdeMatch = !searchFilters.ocde ? true : beca.ocde.some((ocde) => ocde.id == searchFilters.ocde);
    const odsMatch = !searchFilters.ods ? true : beca.ods.some((ods) => ods.id == searchFilters.ods);
    const countryMatch = !searchFilters.country ? true : beca.country.id == searchFilters.country;
    const typeMatch = !searchFilters.type ? true : beca.type == searchFilters.type;
    const startDateMatch = !searchFilters.startDate ? true : beca.start_date == searchFilters.startDate;
    const endDateMatch = !searchFilters.endDate ? true : beca.end_date == searchFilters.endDate;
    const statusMatch = searchFilters.status === "" ? true : beca.status == searchFilters.status;
    return ocdeMatch && odsMatch && typeMatch && startDateMatch && endDateMatch && countryMatch && statusMatch;
  });
  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.slice(0, maxLength - 3) + "...";
    }
    return text;
  };
  useEffect(() => {
    const handleResize = () => {
      if (odsSelect.current) {
        const selectWidth3 = odsSelect.current.offsetWidth;
        const chars3 = Math.floor(selectWidth3 / 6.9);
        const arrayConNuevaClave3 = odsOptions.map((objeto) => ({
          ...objeto,
          truncatedText: truncateText(
            objeto.name + " - " + objeto.description,
            chars3
          )
        }));
        setOdsOptions(arrayConNuevaClave3);
      }
      if (ocdeSelect.current) {
        const selectWidth4 = ocdeSelect.current.offsetWidth;
        const chars4 = Math.floor(selectWidth4 / 6.9);
        const arrayConNuevaClave4 = ocdeOptions.map((objeto) => ({
          ...objeto,
          truncatedText: truncateText(
            objeto.code + " - " + objeto.name,
            chars4
          )
        }));
        setOcdeOptions(arrayConNuevaClave4);
      }
    };
    window.addEventListener("resize", handleResize);
    handleResize();
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return /* @__PURE__ */ jsxs(
    Authenticated,
    {
      auth: props.auth,
      errors: props.errors,
      header: /* @__PURE__ */ jsx("h2", { className: "font-semibold text-xl text-gray-800 leading-tight", children: "Buscador de Becas" }),
      children: [
        /* @__PURE__ */ jsx(Head, { title: "Becas" }),
        /* @__PURE__ */ jsx("div", { className: "py-6 mx-3", children: /* @__PURE__ */ jsxs("div", { className: "max-w-7xl mx-auto sm:px-6 lg:px-8", children: [
          /* @__PURE__ */ jsxs("div", { className: "mb-4 inline-flex w-full overflow-hidden rounded-lg bg-white shadow-md", children: [
            /* @__PURE__ */ jsx("div", { className: "flex items-center justify-center bg-blue-500", children: /* @__PURE__ */ jsx(
              "svg",
              {
                className: "h-6 w-6 fill-current text-white",
                viewBox: "0 0 40 40",
                xmlns: "http://www.w3.org/2000/svg",
                children: /* @__PURE__ */ jsx("path", { d: "M20 3.33331C10.8 3.33331 3.33337 10.8 3.33337 20C3.33337 29.2 10.8 36.6666 20 36.6666C29.2 36.6666 36.6667 29.2 36.6667 20C36.6667 10.8 29.2 3.33331 20 3.33331ZM21.6667 28.3333H18.3334V25H21.6667V28.3333ZM21.6667 21.6666H18.3334V11.6666H21.6667V21.6666Z" })
              }
            ) }),
            /* @__PURE__ */ jsx("div", { className: "px-4 flex-grow", children: /* @__PURE__ */ jsxs("div", { className: "border-b border-gray-900/10 pb-2", children: [
              /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "ocde",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "OCDE"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      value: searchFilters.ocde,
                      ref: ocdeSelect,
                      id: "ocde",
                      name: "ocde",
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        ocdeOptions.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.truncatedText
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "ods",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "ODS"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      value: searchFilters.ods,
                      ref: odsSelect,
                      id: "ods",
                      name: "ods",
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        odsOptions.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.truncatedText
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "country",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "País"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      onChange: handleSearch,
                      value: searchFilters.country,
                      id: "country",
                      name: "country",
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        countries.map((item) => /* @__PURE__ */ jsx(
                          "option",
                          {
                            value: item.id,
                            children: item.name
                          },
                          item.id
                        ))
                      ]
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "type",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "Tipo de Beca"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      required: true,
                      onChange: handleSearch,
                      value: searchFilters.type,
                      id: "type",
                      name: "type",
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Seleccionar todos" }),
                        /* @__PURE__ */ jsx("option", { value: "parcial", children: "parcial" }),
                        /* @__PURE__ */ jsx("option", { value: "completa", children: "completa" })
                      ]
                    }
                  ) })
                ] })
              ] }),
              /* @__PURE__ */ jsxs("div", { className: "mt-4 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-4", children: [
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "start_date",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "Fecha de Inicio"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
                    "input",
                    {
                      required: true,
                      value: searchFilters.startDate,
                      type: "date",
                      id: "start_date",
                      onChange: handleSearch,
                      name: "startDate",
                      className: "block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx(
                    "label",
                    {
                      htmlFor: "end_date",
                      className: "block text-sm font-medium leading-6 text-gray-900",
                      children: "Fecha de Fin"
                    }
                  ),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsx(
                    "input",
                    {
                      required: true,
                      value: searchFilters.endDate,
                      type: "date",
                      id: "end_date",
                      onChange: handleSearch,
                      name: "endDate",
                      className: "block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6"
                    }
                  ) })
                ] }),
                /* @__PURE__ */ jsxs("div", { children: [
                  /* @__PURE__ */ jsx("label", { className: "block text-sm font-medium leading-6 text-gray-900", children: "Estado" }),
                  /* @__PURE__ */ jsx("div", { className: "mt-2", children: /* @__PURE__ */ jsxs(
                    "select",
                    {
                      value: searchFilters.status,
                      onChange: handleSearch,
                      className: "block w-full rounded-md border-0  py-2 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300  focus:ring-indigo-600 sm:text-sm",
                      name: "status",
                      children: [
                        /* @__PURE__ */ jsx("option", { value: "", children: "Todos" }),
                        /* @__PURE__ */ jsx("option", { value: 1, children: "Vigente" }),
                        /* @__PURE__ */ jsx("option", { value: 0, children: "No Vigente" })
                      ]
                    }
                  ) })
                ] })
              ] }),
              /* @__PURE__ */ jsx("div", { className: "mt-4 grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-2", children: /* @__PURE__ */ jsxs("div", { className: "col-span-2 flex items-center justify-end", children: [
                /* @__PURE__ */ jsx("p", { className: "mr-3 text-sm text-gray-500", children: `(${data.length ? data.length : 0} registros)` }),
                /* @__PURE__ */ jsx(ExcelReportButton, { data }),
                /* @__PURE__ */ jsx(
                  "button",
                  {
                    onClick: handleClean,
                    className: "rounded-md bg-indigo-600 px-6 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600",
                    children: "Limpiar"
                  }
                )
              ] }) })
            ] }) })
          ] }),
          /* @__PURE__ */ jsx("div", { className: "inline-block min-w-full overflow-hidden rounded-lg shadow", children: /* @__PURE__ */ jsxs("table", { className: "w-full whitespace-no-wrap", children: [
            /* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { className: "border-b bg-gray-50 text-left text-xs font-semibold uppercase tracking-wide text-gray-500", children: [
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Institución" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Nombre Convocatoria" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Fecha de Inicio" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Fecha de Fin" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600 hidden sm:table-cell", children: "Estado" }),
              /* @__PURE__ */ jsx("th", { className: "border-b-2 border-gray-200 bg-gray-100 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600", children: "Más" })
            ] }) }),
            /* @__PURE__ */ jsx("tbody", { children: data.map((beca) => /* @__PURE__ */ jsxs(
              "tr",
              {
                className: "text-gray-700",
                children: [
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: beca.institution }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: beca.name }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: beca.start_date }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx("p", { className: "text-gray-900 whitespace-no-wrap", children: beca.end_date }) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm hidden sm:table-cell", children: /* @__PURE__ */ jsx(
                    "input",
                    {
                      type: "checkbox",
                      checked: beca.status == 1,
                      disabled: true,
                      className: "mr-1"
                    }
                  ) }),
                  /* @__PURE__ */ jsx("td", { className: "border-b border-gray-200 bg-white px-5 py-5 text-sm", children: /* @__PURE__ */ jsx(
                    Link,
                    {
                      className: "text-blue-600 underline whitespace-no-wrap hover:text-gray-900",
                      href: route(
                        "becas.show",
                        { id: beca.id }
                      ),
                      children: "Información"
                    }
                  ) })
                ]
              },
              beca.id
            )) })
          ] }) })
        ] }) })
      ]
    }
  );
}
export {
  Index as default
};
